/** Automatically generated file. DO NOT MODIFY */
package dizzy.med.jhu.edu.mjs.Skew1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}