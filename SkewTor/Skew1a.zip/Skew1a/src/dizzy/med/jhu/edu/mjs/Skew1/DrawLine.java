package dizzy.med.jhu.edu.mjs.Skew1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class DrawLine extends View {

    Paint paint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint paint2 = new Paint(Paint.ANTI_ALIAS_FLAG);

    // public MyCustomView(Context context, AttributeSet attrs) { super(context, attrs); } 
    public DrawLine(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint1.setColor(Color.RED);
        paint2.setColor(Color.BLUE);
        paint1.setStrokeWidth((float) 3.5);
        paint2.setStrokeWidth((float) 3.5);
        paint1.setAlpha(128);
        paint2.setAlpha(128);   
    }

    @Override
    public void onDraw(Canvas canvas) {
            canvas.drawLine(100, 500, 700, 500, paint1);
            canvas.drawLine(100, Global.ypos-Global.yang, 700, Global.ypos+Global.yang, paint2);
    }

}
