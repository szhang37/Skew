package dizzy.med.jhu.edu.mjs.Skew1;


// Changes March 26, 2013, ms
// Add date/time to data file stream to get time-to-complete.
// Only show data at bottom if file storage is off.
// Set alpha values for lines to reduce intensity and allow overlap.

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.UUID;
import java.util.Date;
import java.text.DateFormat;

import android.content.Intent;
import android.net.Uri;

import dizzy.med.jhu.edu.mjs.Skew1.R;
import dizzy.med.jhu.edu.mjs.Skew1.SensorActivity;
import android.view.View;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;


@SuppressWarnings("deprecation")
public class Skew1Activity extends Activity {
    /** Called when the activity is first created. */
    
	private DrawLine mLine;
	private SensorActivity mAccel;
	private TextView mText;
	private Button mButtonTopR;
	private Button mButtonBotR;
	private Button mButtonBotL;
	private Button mButtonRadV;
	private Button mButtonRadT;
	private Button mButtonOpen;
	private Button mButtonClose;
	private int mode;	// 1=vert, 2=tor
	private Random random = new Random();
	private String dataFileName = null;
	private OutputStream dataStream = null;
	
    DrawLine drawLine;
    
    SensorActivity accel;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        drawLine = new DrawLine(this, null);
        drawLine.setBackgroundColor(Color.BLACK);
        
//        accel = new SensorActivity();
        
        // get handles to Views defined in our layout file
        mLine = (DrawLine)findViewById(R.id.line);
        mText = (TextView) findViewById(R.id.text);
        mButtonBotR = (Button) findViewById(R.id.button2);
        mButtonBotL = (Button) findViewById(R.id.button1);
        mButtonTopR = (Button) findViewById(R.id.button4);
        mButtonRadV = (Button) findViewById(R.id.radioVertical);
        mButtonRadT = (Button) findViewById(R.id.radioTorsional);
        mButtonOpen = (Button) findViewById(R.id.button_newfile);
        mButtonClose = (Button) findViewById(R.id.button_closefile);
        
        // up or cw   
        mButtonBotR.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mode==1) Global.ypos = Global.ypos - 1;
                if (mode==2) Global.yang = Global.yang + 1;
                if (dataFileName == null)
                	{mText.setText(String.format("%s  ypos %d  yang %d", dataFileName, Global.ypos, Global.yang));}
                else
                	{mText.setText(String.format("%s", dataFileName));}
                mLine.postInvalidate();}});
 
        // down or ccw
        mButtonBotL.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mode==1) Global.ypos = Global.ypos + 1;
                if (mode==2) Global.yang = Global.yang - 1;
                if (dataFileName == null)
            		{mText.setText(String.format("%s  ypos %d  yang %d", dataFileName, Global.ypos, Global.yang));}
                else
            		{mText.setText(String.format("%s", dataFileName));}
                mLine.postInvalidate();}});

        //  new trial
        mButtonTopR.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	if(dataStream != null) {
            		PrintStream ps = new PrintStream(dataStream);
            		Date date = new Date();
                	ps.println(String.format("end    ypos %d  yang %d  %s  yaw %f  pitch %f  roll %f", Global.ypos, Global.yang, date, Global.yaw, Global.pitch, Global.roll));
            		}
                if (mode==1) Global.ypos = random.nextInt(40) + 500 - 30;
                if (mode==2) Global.yang = random.nextInt(30) - 15;
            	if(dataStream != null) {
            		PrintStream ps = new PrintStream(dataStream);
            		Date date = new Date();
                	ps.println(String.format("start  ypos %d  yang %d  %s  yaw %f  pitch %f  roll %f", Global.ypos, Global.yang, date, Global.yaw, Global.pitch, Global.roll));
             		}
                if (dataFileName == null)
            		{mText.setText(String.format("%s  ypos %d  yang %d", dataFileName, Global.ypos, Global.yang));}
                else
            		{mText.setText(String.format("%s", dataFileName));}
                mLine.postInvalidate();}});
        
        // set vertical mode
        mButtonRadV.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		mode = 1;
        		Global.yang = 0;
                if (dataFileName == null)
                	{mText.setText(String.format("%s  ypos %d  yang %d", dataFileName, Global.ypos, Global.yang));}
                else
            		{mText.setText(String.format("%s", dataFileName));}
        		mLine.postInvalidate();}});
        
        // set torsional mode
        mButtonRadT.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			mode = 2;
    			Global.ypos = 530;
                if (dataFileName == null)
            		{mText.setText(String.format("%s  ypos %d  yang %d", dataFileName, Global.ypos, Global.yang));}
                else
            		{mText.setText(String.format("%s", dataFileName));}
    			mLine.postInvalidate();}});

        // open new file
        mButtonOpen.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		NewDataFile();
                mText.setText(String.format(dataFileName));
    			mLine.postInvalidate();}});

        // close file
        mButtonClose.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		CloseDataFile();
                mText.setText(String.format("<no file>"));
    			mLine.postInvalidate();}});
        
//        public void onButtonNewFile(View v) NewDataFile();
        
//        public void onButtonCloseFile(View v) CloseDataFile();
  
        
}
    
  
    private void NewDataFile() {

    	// First close old file, if it is open.
    	if(dataStream != null) CloseDataFile();

//    	mValueTV.setText("<No File>");

    	Date date = new Date();
    	dataFileName = String.format("%4d_%02d%02d_%02d%02d%02d_skew",
    	date.getYear()+1900, date.getMonth()+1, date.getDate(),
    	date.getHours(), date.getMinutes(), date.getSeconds());

    	// Can leave this in if you need to create a new directory. Otherwise, the NASA directory
    	// should be on both Androids.
    	//
    	// File newdir = new File(Environment.getExternalStorageDirectory()
    	// + File.separator + "NASA");
    	// newdir.mkdir();

    	File file = new File(Environment.getExternalStorageDirectory()
    	+ File.separator + "NASA"
    	+ File.separator + dataFileName);

//    	Log.w(TAG, "Trying to write out to file.");

    	try {
    	file.createNewFile();
    	dataStream = new FileOutputStream(file);
    	}
    	catch(FileNotFoundException e) {
//    	Log.e(TAG, "File Not Found!!!", e);
    	return;}
    	catch(IOException e) {
//    	Log.e(TAG, "IO Exception writing to file.", e);
    	return;}

//    	mValueTV.setText(dataFileName);
    	}

    	private void CloseDataFile()
    	{
    	if(dataStream==null) return;
    	try {dataStream.close();}
    	catch(IOException e) {}
    	dataStream = null;
    	dataFileName = null;
//    	mValueTV.setText("<No File>");

    	// Trying to get it to flush the file out so it shows up immediately on the PC.
    	// THIS WORKS! Files are updated immediately in Windows.
    	sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED,
    	Uri.parse("file://"
    	+ Environment.getExternalStorageDirectory()
    	+ "/NASA")));
    	}

}




