package dizzy.med.jhu.edu.mjs.Skew1;

public class Global {
	public static int ypos = 510;
	public static int yang = 10;
	public static float yaw, pitch, roll;
}
